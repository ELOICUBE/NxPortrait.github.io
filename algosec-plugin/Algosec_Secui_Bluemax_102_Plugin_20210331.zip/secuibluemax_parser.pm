#!/usr/bin/perl

# Parse logs from Secui MF2 devices
#
# $Id: secuimf2_parser.pm

use strict;
use warnings;

package secuibluemax_parser;
my @ignore_regexps;
#my $PARSER_EXCLUDE_FILENAME = "secuimf2_parser_exclude.txt";

sub parserId
{
	return "secuibluemax";
}

sub init
{
	my $exclude;
	my $line;
	my $parser_name = parserId();
	
	return 1;
}


sub who_am_I
{  
    my $log_message = shift;
    my $header;
	if ($log_message =~ /^(\w{3}\s{1,2}\d{1,2}\s\d{2}:\d{2}:\d{2})\s+(\S+)\s(\S*)\s(\S*)\s(\[.*)/)
    { 
    	  #$header->{"timestamp"} = $1;
	      $header->{"timestamp"} = time();
	      $header->{"timestamp"} =~ s/\-/\//g;
		  $header->{"hostname"} = $2;
		  $header->{"message"} = $3 . $4 . $5;
          $header->{"parserId"} = parserId();
		  return \$header;
	} 
	return 0;
}

sub parse
{
	my $message = shift;
	my $logFields = shift;
	my $headerFields = shift;
	my $log_line_time = shift;
	my $status;
	
	#---------------fw4_allow--------------------
	#Jul 11 19:42:11 10.10.100.253 1 2018-07-11T10:22:44.629940Z [fw4_allow] [10.10.100.253]2018-07-11 19:21:40,2018-07-11 19:22:40,60,aplenet_NFR_1,26,-,10.10.60.6,,68,255.255.255.255,67,UDP,EXT,eth6,1,0,346,0, ,-,-
    #Feb 26 13:19:57 192.168.10.10 1 2017-02-26T04:20:22.000897Z [fw4_allow] [192.168.10.10]2017-02-26 13:20:03,2017-02-26 13:20:08,5,tangun_secui,23,-,10.10.10.100,,54337,125.209.222.141,80,TCP,INT,eth1,31,66,2068,94690, ,3Way OK / FIN2 [SAF:SAF],-
	if($message =~ m/\[fw4_allow\] \[(?<g1>.*?)\](?<g2>.*?),(?<g3>.*?),(?<g4>.*?),(?<g5>.*?),(?<g6>.*?),(?<g7>.*?),(?<g8>.*?),(?<g9>.*?),(?<g10>.*?),(?<g11>.*?),(?<g12>.*?),(?<g13>.*?),(?<g14>.*?),(?<g15>.*?),(?<g16>.*?),(?<g17>.*?),(?<g18>.*?),(?<g19>.*?),(?<g20>.*?),(?<g21>.*?),/ )
	{			
#g6  > RuleID
#g10 > Source Address
#g13 > Destination Address
#g14 > Destination Port
#g15 > Protocol
		
		
		$logFields->{'type'} = 'traffic';
		$logFields->{'action'} = 'allow';
		$logFields->{'device_id'} = $5;
		$logFields->{'policy_id'} = $6;
		$logFields->{'src_ip'} = $10;
		$logFields->{'dst_ip'} = $13;
		$logFields->{'dst_port'} = $14;
		my $service = $15;
		if($service == "1")
		{
			$logFields->{'protocol'} = 'ICMP';
		}
		elsif($service == "6")
		{
			$logFields->{'protocol'} = 'TCP';
		}
		elsif($service == "17")
		{
			$logFields->{'protocol'} = 'UDP';
		}
			
		$log_line_time = $2;
		my ($year, $month, $day) = $log_line_time =~ /(\d{4})\-(\d{2})\-(\d{2})/;
		$day =~ s/^0//;
		$log_line_time = $year . $month . $day;
		$logFields->{'start_date'} = $log_line_time;
		$logFields->{'virtual_system'} = $5;
		#$headerFields->{'hostname'};					
	}
	#---------------fw4_deny--------------------
	#Jul 12 09:36:11 10.10.100.253 1 2018-07-12T00:16:42.000494Z [fw4_deny] [10.10.100.253]2018-07-12 09:16:42,2018-07-12 09:16:42,0,aplenet_NFR_1,26,-,10.10.60.14,,137,10.10.60.255,137,UDP,EXT,eth6,1,96, ,-,Deny by Deny Rule
    #Jul 12 09:36:12 10.10.100.253 1 2018-07-12T00:16:43.000418Z [fw4_deny] [10.10.100.253]2018-07-12 09:16:43,2018-07-12 09:16:43,0,aplenet_NFR_1,26,-,10.10.60.14,,137,10.10.60.255,137,UDP,EXT,eth6,1,96, ,-,Deny by Deny Rule
	if($message =~ m/\[fw4_deny\] \[(?<g1>.*?)\](?<g2>.*?),(?<g3>.*?),(?<g4>.*?),(?<g5>.*?),(?<g6>.*?),(?<g7>.*?),(?<g8>.*?),(?<g9>.*?),(?<g10>.*?),(?<g11>.*?),(?<g12>.*?),(?<g13>.*?),(?<g14>.*?),(?<g15>.*?),(?<g16>.*?),(?<g17>.*?),(?<g18>.*?),(?<g19>.*?),(?<g20>.*)/)
	{ 
		$logFields->{'type'} = 'traffic';
		$logFields->{'action'} = 'deny';
		$logFields->{'device_id'} = $5;
		$logFields->{'policy_id'} = $6;
		$logFields->{'src_ip'} = $10;
		$logFields->{'dst_ip'} = $13;
		$logFields->{'dst_port'} = $14;
		my $service = $15;
		if($service == "1")
		{
			$logFields->{'protocol'} = 'ICMP';
		}
		elsif($service == "6")
		{
			$logFields->{'protocol'} = 'TCP';
		}
		elsif($service == "17")
		{
			$logFields->{'protocol'} = 'UDP';
		}           

		$log_line_time = $2;
		my ($year, $month, $day) = $log_line_time =~ /(\d{4})\-(\d{2})\-(\d{2})/;
		$day =~ s/^0//;
		$log_line_time = $year . $month . $day;
		$logFields->{'start_date'} = $log_line_time;
		$logFields->{'virtual_system'} = $5; 
	}

	if($message =~ m/\[audit\] \[(?<g1>.*?)\](?<g2>.*?),(?<g3>.*?),(?<g4>.*?),(?<g5>.*?),(?<g6>.*?),(?<g7>.*?),FW_RULE_COMMIT/)
	{
		$logFields->{'type'} = 'audit';
		$logFields->{'device_id'} = $headerFields->{'hostname'}; 
		$logFields->{'virtual_system'} = $headerFields->{'hostname'}; 

		#modified user
		$logFields->{'user'} = $4; 
		
		#rule/host/service
		$logFields->{'object_type'} = 'rule'; 
		
		#objects name
		$logFields->{'object_name'} = 'Unknown';
		
		#add/edit/delete 
		$logFields->{'action'} = 'modify'; 
		
		#message information
		$logFields->{'detail'} = '';
		
		$log_line_time = $2;
		
		$log_line_time =~ s/\-/\//g;
		$logFields->{'timeGen'} = $log_line_time;  
		$headerFields->{'timestamp'} = $log_line_time;
		#$log_line_time;	
	}
	return 1;
}


sub log_time2str
{
	my $start_time = shift;
	my $log_year;
	
	my %number_of_month = ('Jan'=>"01",'Feb'=>"02", 'Mar'=>"03", 'Apr'=>"04", 'May'=>"05", 'Jun'=>"06",
                           'Jul'=>"07",'Aug'=>"08", 'Sep'=>"09", 'Oct'=>"10", 'Nov'=>"11", 'Dec'=>"12");
    my ($log_mon,$log_mday,$log_hour,$log_min,$log_sec) = $start_time =~ /^(\w{3})\s{1,2}(\d{1,2})\s(\d{2}):(\d{2}):(\d{2})/;
    if (!defined $log_mon) { # match an expression including the year
	($log_mon,$log_mday,$log_year,$log_hour,$log_min,$log_sec) = $start_time =~ /^(\w{3})\s{1,2}(\d{1,2})\s(\d{4})\s(\d{2}):(\d{2}):(\d{2})/;
	}
    $log_mon = $number_of_month{$log_mon};
    $log_mday =~ s/^(\d)$/0$log_mday/;
    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
    $log_year = $year + 1900 if (!defined $log_year);
    if($mon ne $log_mon)
    {
    	if($mon eq "12" && $log_mon eq "01")
    	{
    		$log_year += 1;
    	} else
    	{
    		if($mon eq "01" && $log_mon eq "12")
    		{
    			$log_year -= 1;
    		}
    	} 
    }
    $start_time = "$log_year/$log_mon/$log_mday $log_hour:$log_min:$log_sec";
    return $start_time;
}
return 1;
