﻿`Plugin 등록 방법

1. "secuibluemax" 폴더를 아래 경로에 복사합니다.
   /usr/share/fa/data/plugins

2. "secui.bluemax.v102.jar" 파일을 아래 경로에 복사하고 권한을 변경합니다.
   /usr/share/fa/bin
   권한을 777로 변경

3. "secuibluemax_parser.pm" 파일을 아래 경로에 복사하고 권한을 변경합니다.
   /usr/share/fa/data/syslog_processor/parsers
   Owner 및 Group을 afa로 변경
   권한을 777로 변경

4. "orig_rules_info.secuibluemax" 파일을 아래 경로에 복사합니다.
   /usr/share/fa/data


5. afa 계정으로 전환하고 플러그인을 설치합니다.
   su afa
   fa_install_plugin /usr/share/fa/data/plugins/secuibluemax/brand_config.xml 



정상 설치 및 동작 확인 방법

1. AFA에 로그인 합니다.
   - Plugin 설치 및 변경 후 AFA에서 로그아웃 후 재로그인해야 변경사항이 반영됩니다.

2. Add Device의 장비 목록에서 secuibluemax 가 있는지 확인합니다.

3. 장비 등록 후 Analyze를 수행합니다.

4. 아래 경로에 secuibluemax_parser.pm 파일이 생성되었는지 확인합니다.
   /data/algosec/syslog_processor/parsers

5. 아래 경로에서 ProcessLogs.log 파일의 내용을 확인합니다.
   /data/algosec/syslog_processor/logs

   예) 10_10_100_253 secuimf2 0 0  10.10.100.253
       등록된 방화벽 장비 IP, 플러그인 또는 장비 명, Additional Identifier가 정상적으로 등록되어 있는지 확인

   예) Using secuimf2_parser script
       로그 파서가 정상적으로 등록되어 실행중인지 확인

6. /data/algosec/syslog_processor/output 폴더로 이동 후 다음 사항을 확인합니다.
   SyslogRawData.Log
   SyslogRawData.log.1 이 두가지 파일만 보이는 경우 로그 파서가 정상적으로 동작하지 않거나 파싱할 로그가 수신되지 않는 것입니다.

   정상적으로 로그를 파싱할 경우에는 위 2개 파일 이외에
   temp_fw_dst_log-0d5d92a8-9cb2-4d59-8749-a4fa1d6ad4eb-1533298559-1533299014
   temp_fw_log-0d5d92a8-9cb2-4d59-8749-a4fa1d6ad4eb-1533298559-1533299014
   temp_fw_src_log-0d5d92a8-9cb2-4d59-8749-a4fa1d6ad4eb-1533298559-1533299014
   temp_fw_srv_log-6be65ffb-3e50-4105-9a21-e03f0d6eaab6-1533298559-1533298897 와 같은 Temp text 파일이 생성됩니다.
   * output 폴더에 저장되는 파일은 로그 파싱 주기에 따라 갱신됩니다.

7. afa 계정으로 전환하고 아래 명령어를 실행합니다.
   su afa
   TrafficLogManager

8. TrafficLogManager에서 "3.Get Info"를 선택하고 "2.Get number of device's log records from DB"를 선택한 후 등록된 시큐아이장비 IP, 기간을 입력합니다.
   Source, Destination, Service 정보가 DB에 정상적으로 쓰여지는지 확인합니다.

9. AFA의 보고서에서 IPT, Rule Usage가 정상적으로 나오는지 확인합니다.

- 끝 -   
 

		
		

